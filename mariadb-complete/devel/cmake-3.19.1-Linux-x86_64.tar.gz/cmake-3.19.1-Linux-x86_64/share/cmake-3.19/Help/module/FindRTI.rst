.. cmake-module:: ../../Modules/FindRTI.cmake
