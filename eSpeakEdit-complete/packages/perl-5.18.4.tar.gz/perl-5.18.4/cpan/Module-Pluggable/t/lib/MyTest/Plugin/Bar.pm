package MyTest::Plugin::Bar;


use strict;


1;


