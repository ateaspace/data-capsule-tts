use warnings;
use strict;

sub main::scope0_test { $main::t[3] }

1;
