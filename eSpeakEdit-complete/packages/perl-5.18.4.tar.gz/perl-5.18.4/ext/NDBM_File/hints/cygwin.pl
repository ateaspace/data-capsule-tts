# uses GDBM ndbm compatibility feature
$self->{LIBS} = ['-lgdbm -lgdbm_compat'];
