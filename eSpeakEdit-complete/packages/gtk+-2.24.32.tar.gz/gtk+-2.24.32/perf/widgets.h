#include <gtk/gtk.h>

GtkWidget *appwindow_new (void);

GtkWidget *text_view_new (void);

GtkWidget *tree_view_new (void);
