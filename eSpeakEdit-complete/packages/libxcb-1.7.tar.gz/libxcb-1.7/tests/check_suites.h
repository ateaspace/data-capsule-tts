#include <check.h>

void suite_add_test(Suite *s, TFun tf, const char *name);
Suite *public_suite(void);
