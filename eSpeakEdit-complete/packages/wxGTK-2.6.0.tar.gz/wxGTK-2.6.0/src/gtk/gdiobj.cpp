/////////////////////////////////////////////////////////////////////////////
// Name:        gdiobj.cpp
// Purpose:     wxGDIObject class
// Author:      Julian Smart
// RCS-ID:      $Id: gdiobj.cpp,v 1.7 2004/05/23 20:52:20 JS Exp $
// Copyright:   (c) Julian Smart
// Licence:   	wxWindows licence
/////////////////////////////////////////////////////////////////////////////

#if defined(__GNUG__) && !defined(NO_GCC_PRAGMA)
#pragma implementation "gdiobj.h"
#endif

#include "wx/gdiobj.h"

IMPLEMENT_DYNAMIC_CLASS(wxGDIObject, wxObject)

