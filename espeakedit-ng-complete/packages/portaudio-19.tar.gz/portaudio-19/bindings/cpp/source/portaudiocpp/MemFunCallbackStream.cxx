#include "portaudiocpp/MemFunCallbackStream.hxx"

// (... template class ...)

