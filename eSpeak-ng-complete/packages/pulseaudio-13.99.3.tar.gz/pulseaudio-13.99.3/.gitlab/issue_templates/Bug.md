### Warning  
Missing data may cause bugs to languish.  

### Summary  
(Summarize the bug encountered concisely) 
  
### environment  
Check to see if you have pa-info installed by running `which pa-info`  
If yes please run it  
If no please download and run https://gitlab.freedesktop.org/pulseaudio/pulseaudio/blob/master/src/utils/pa-info  
Attach the output to this bug report as pa-info.txt  

### Steps to reproduce  
(How one can reproduce the issue - this is very important)  
  
  
### What is the current *bug* behavior?  
(What actually happens)  
  
### What is the expected *correct* behavior?  
(What you should see instead)  
  