/* empty file, just here to allow us to compile an unmodified resampler2.c */
